from FMD3.extensions.enrichers.IEnricher import IEnricher


class DemoEnricher(IEnricher):
    ID = "TestEnricher"
    NAME = "TestEnricher"