from FMD3.extensions.enrichers.IEnricher import IEnricher


class TestEnricher(IEnricher):
    ID = "TestEnricher"
    NAME = "TestEnricher"