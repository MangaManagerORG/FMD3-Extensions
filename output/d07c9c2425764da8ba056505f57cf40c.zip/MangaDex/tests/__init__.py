import unittest


class TestMangaDex(unittest.TestCase):
    def test_works(self):
        self.assertTrue(True)
        #TOdo add tests