from .MangaDex import MangaDex
from .__version__ import __version__

Source = MangaDex
Source.VERSION = __version__
